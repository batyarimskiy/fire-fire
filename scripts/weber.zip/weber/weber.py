import requests, json, re, colorama, os
import threading

os.system('clear')
print("""
                             mm
                            m@@
                             @@
*@@*    m@    *@@*  mm@*@@   @@m@@@@m    mm@*@@ *@@@m@@@
  @@   m@@@   m@   m@*   @@  @@    *@@  m@*   @@  @@* **
   @@ m@  @@ m@    !@******  !@     @@  !@******  @!
    @@@    @!!     !@m    m  !!!   m@!  !@m    m  @!
    !@!!   !:!     !!******  !!     !!  !!******  !!
    !!!    !:!     :!!       :!!   !!!  :!!       !:
     :      :       : : ::   : : : ::    : : :: : :::

""")
print("Введите домен сайта: ")
url = input("\033[35mweber> \033[0m")
ufd = url.replace("https://", "").replace("http://", "")
try:
    io = 0
    urls = ["http://api.hackertarget.com/whois/", "http://api.hackertarget.com/geoip/", "http://api.hackertarget.com/dnslookup/", "http://api.hackertarget.com/subnetcalc/", "http://api.hackertarget.com/nmap/", "http://api.hackertarget.com/nmap/"]
    while io<len(urls)-1:
        try:
            pars_dom = requests.get(urls[io], params={"q":ufd}).text
            print("\033[32m"+pars_dom+"\033[0m")
        except:
            print("\033[35mКритическая ошибка\033[0m")
            break
        io+=1
    input("Нажмите Enter для продолжения")
    os.system("python3 dirsearch.py -u "+url+" -e html")
    with open('subs.txt', 'r') as f:
        sub = f.read().splitlines()
    def sca1n(sca):
        if sca == '':
            sca = 300
        elif sca == "/very fas":
            sca = 300
        elif sca == "/fast":
            sca = 600
        elif sca == "/medium":
            sca = 1200
        elif sca == "/slow":
            sca = 2400
        elif sca == "/very slow":
            sca = 4800
        else:
            sca = 300
        i=0
        if url[4]=="s":
            ht = "https"
        else:
            ht = "http"
        while i<sca:
            try:
                otwet = requests.get(ht+"://"+sub[i]+"."+ufd)
                if otwet.status_code == 200:
                    print("\033[32m["+str(str(otwet.status_code)+"]"+ht+"://"+sub[i]+"."+ufd)+"\033[0m")
                elif otwet.status_code == 403:
                    print("\033[33m["+str(str(otwet.status_code)+"]"+ht+"://"+sub[i]+"."+ufd)+"\033[0m")
                elif otwet.status_code == 300:
                    print("\033[35m["+str(str(otwet.status_code)+"]"+ht+"://"+sub[i]+"."+ufd)+"\033[0m")
                elif otwet.status_code == 400:
                    print("\033[34m["+str(str(otwet.status_code)+"]"+ht+"://"+sub[i]+"."+ufd)+"\033[0m")
                else:
                    print("["+str(str(otwet.status_code)+"]"+ht+"://"+sub[i]+"."+ufd)+"")
            except:
                print("\033[F[???]"+ht+"://"+sub[i]+"."+ufd+"")
            i+=1
        print("          @batyarimskiy          ")
        print("      t.me/weaknessinjection    ")
    print("""
    Сканирование под-доменов:
    \033[35m/very fast - \033[32m[~5min] min\033[0m
    \033[35m/fast      - \033[32m[~10min]\033[0m
    \033[35m/medium    - \033[33m[~20min]\033[0m
    \033[35m/slow      - \033[31m[~40min]\033[0m
    \033[35m/very slow - \033[31m[1h+]   max\033[0m
    """)
    sca = input("\033[35mweber> \033[0m")
    sca1n(sca)
except:
    print("\033[31mНе удалось определить сайт           \033[0m")
